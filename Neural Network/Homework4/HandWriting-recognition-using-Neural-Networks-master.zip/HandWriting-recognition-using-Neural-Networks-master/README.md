# HandWriting-recognition-using-Neural-Networks
3 layer Neural Network trained with 5000 examples and also applied multi-class linear logistic regression using one-vs-all algo
