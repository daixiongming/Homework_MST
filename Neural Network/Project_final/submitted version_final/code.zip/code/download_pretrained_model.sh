mkdir -p data/models/densecap
cd data/models/densecap
unzip densecap-pretrained-vgg16.t7.zip
rm densecap-pretrained-vgg16.t7.zip
cd ../../../
