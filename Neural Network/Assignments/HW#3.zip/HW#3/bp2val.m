function y=bp2val(P,W1,W2,beta);
%BP2VAL - output of the MLP NN with one hidden layer/ predicted values
%usage - y=bp2val(P,W1,W2,beta);
%
% P: n by Q matrix containing Q, n-dimensional input vectors
% W1: weights from the input to the hidden layer
% W2: weights from the hidden layer to the output layer
% beta: slope of the activation function, f(x)=tanh(beta*x)
% y: m by Q matrix containing Q, m-dimensional output vectors

% Forward step code (10 pts)
y=zeros(m,Q);
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Type your code here %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% End of your code %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
